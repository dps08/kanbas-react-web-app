const REMOTE_SERVER = process.env.REACT_APP_REMOTE_SERVER;
export default function EnvironmentVariables() {

  return (
    <div id="wd-environment-variables">
      <h3>Environment Variables</h3>
      
      <p>Remote Server: https://kanbas-node-server-app-divit-2bc1b0d87817.herokuapp.com</p><hr/>
    </div>
  );
}
